#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	printf("sizeof(char *) = %d\n", sizeof(char *));
	printf("sizeof(short *) = %d\n", sizeof(short *));
	printf("sizeof(int *) = %d\n", sizeof(int *));
	printf("sizeof(long *) = %d\n", sizeof(long *));
	printf("sizeof(float *) = %d\n", sizeof(float *));
	printf("sizeof(double *) = %d\n", sizeof(double *));
	printf("sizeof(long double *) = %d\n", sizeof(long double *));
	printf("sizeof(void *) = %d\n", sizeof(void *));
	return 0;
}
